﻿namespace name_sorter
{
    partial class name_sorter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.TBP_BASE = new System.Windows.Forms.TableLayoutPanel();
            this.TBP_CONTROL = new System.Windows.Forms.TableLayoutPanel();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.DGV_UNSORTED = new System.Windows.Forms.DataGridView();
            this.DGV_SORTED = new System.Windows.Forms.DataGridView();
            this.BTN_HOW = new System.Windows.Forms.PictureBox();
            this.BTN_CLOSE = new System.Windows.Forms.PictureBox();
            this.BTN_MIN = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel2 = new System.Windows.Forms.TableLayoutPanel();
            this.LBL_UNSORTED = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.tableLayoutPanel3 = new System.Windows.Forms.TableLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.BTN_SORT = new System.Windows.Forms.Button();
            this.RB_FIRST = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.RB_GIVEN = new System.Windows.Forms.RadioButton();
            this.TBP_BASE.SuspendLayout();
            this.TBP_CONTROL.SuspendLayout();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_UNSORTED)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_SORTED)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_HOW)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_CLOSE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_MIN)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.tableLayoutPanel2.SuspendLayout();
            this.tableLayoutPanel3.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TBP_BASE
            // 
            this.TBP_BASE.ColumnCount = 1;
            this.TBP_BASE.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBP_BASE.Controls.Add(this.tableLayoutPanel1, 0, 1);
            this.TBP_BASE.Controls.Add(this.tableLayoutPanel2, 0, 0);
            this.TBP_BASE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.TBP_BASE.Location = new System.Drawing.Point(0, 0);
            this.TBP_BASE.Name = "TBP_BASE";
            this.TBP_BASE.RowCount = 2;
            this.TBP_BASE.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 72F));
            this.TBP_BASE.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBP_BASE.Size = new System.Drawing.Size(717, 378);
            this.TBP_BASE.TabIndex = 0;
            // 
            // TBP_CONTROL
            // 
            this.TBP_CONTROL.ColumnCount = 3;
            this.TBP_CONTROL.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TBP_CONTROL.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TBP_CONTROL.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.TBP_CONTROL.Controls.Add(this.BTN_HOW, 2, 0);
            this.TBP_CONTROL.Controls.Add(this.BTN_CLOSE, 1, 0);
            this.TBP_CONTROL.Controls.Add(this.BTN_MIN, 0, 0);
            this.TBP_CONTROL.Location = new System.Drawing.Point(570, 3);
            this.TBP_CONTROL.Name = "TBP_CONTROL";
            this.TBP_CONTROL.RowCount = 1;
            this.TBP_CONTROL.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.TBP_CONTROL.Size = new System.Drawing.Size(144, 66);
            this.TBP_CONTROL.TabIndex = 0;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 3;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33334F));
            this.tableLayoutPanel1.Controls.Add(this.tableLayoutPanel3, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox4, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.DGV_UNSORTED, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.DGV_SORTED, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox2, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.pictureBox3, 2, 2);
            this.tableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 72);
            this.tableLayoutPanel1.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 3;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 31F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(717, 306);
            this.tableLayoutPanel1.TabIndex = 1;
            // 
            // DGV_UNSORTED
            // 
            this.DGV_UNSORTED.AllowUserToAddRows = false;
            this.DGV_UNSORTED.AllowUserToDeleteRows = false;
            this.DGV_UNSORTED.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_UNSORTED.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DGV_UNSORTED.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_UNSORTED.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_UNSORTED.Location = new System.Drawing.Point(0, 31);
            this.DGV_UNSORTED.Margin = new System.Windows.Forms.Padding(0);
            this.DGV_UNSORTED.Name = "DGV_UNSORTED";
            this.DGV_UNSORTED.ReadOnly = true;
            this.DGV_UNSORTED.Size = new System.Drawing.Size(238, 244);
            this.DGV_UNSORTED.TabIndex = 0;
            // 
            // DGV_SORTED
            // 
            this.DGV_SORTED.AllowUserToAddRows = false;
            this.DGV_SORTED.AllowUserToDeleteRows = false;
            this.DGV_SORTED.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.DGV_SORTED.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.DGV_SORTED.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.DGV_SORTED.Dock = System.Windows.Forms.DockStyle.Fill;
            this.DGV_SORTED.Location = new System.Drawing.Point(477, 31);
            this.DGV_SORTED.Margin = new System.Windows.Forms.Padding(0);
            this.DGV_SORTED.Name = "DGV_SORTED";
            this.DGV_SORTED.ReadOnly = true;
            this.DGV_SORTED.Size = new System.Drawing.Size(240, 244);
            this.DGV_SORTED.TabIndex = 1;
            // 
            // BTN_HOW
            // 
            this.BTN_HOW.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BTN_HOW.Image = global::name_sorter.Properties.Resources.how;
            this.BTN_HOW.Location = new System.Drawing.Point(96, 3);
            this.BTN_HOW.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.BTN_HOW.Name = "BTN_HOW";
            this.BTN_HOW.Size = new System.Drawing.Size(48, 60);
            this.BTN_HOW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BTN_HOW.TabIndex = 2;
            this.BTN_HOW.TabStop = false;
            this.BTN_HOW.Click += new System.EventHandler(this.BTN_HOW_Click);
            // 
            // BTN_CLOSE
            // 
            this.BTN_CLOSE.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BTN_CLOSE.Image = global::name_sorter.Properties.Resources.close;
            this.BTN_CLOSE.Location = new System.Drawing.Point(48, 3);
            this.BTN_CLOSE.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.BTN_CLOSE.Name = "BTN_CLOSE";
            this.BTN_CLOSE.Size = new System.Drawing.Size(48, 60);
            this.BTN_CLOSE.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BTN_CLOSE.TabIndex = 1;
            this.BTN_CLOSE.TabStop = false;
            this.BTN_CLOSE.Click += new System.EventHandler(this.BTN_CLOSE_Click);
            // 
            // BTN_MIN
            // 
            this.BTN_MIN.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.BTN_MIN.Dock = System.Windows.Forms.DockStyle.Fill;
            this.BTN_MIN.Image = global::name_sorter.Properties.Resources.min;
            this.BTN_MIN.Location = new System.Drawing.Point(0, 3);
            this.BTN_MIN.Margin = new System.Windows.Forms.Padding(0, 3, 0, 3);
            this.BTN_MIN.Name = "BTN_MIN";
            this.BTN_MIN.Size = new System.Drawing.Size(48, 60);
            this.BTN_MIN.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.BTN_MIN.TabIndex = 0;
            this.BTN_MIN.TabStop = false;
            this.BTN_MIN.Click += new System.EventHandler(this.BTN_MIN_Click);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox4.Image = global::name_sorter.Properties.Resources.bottom;
            this.pictureBox4.Location = new System.Drawing.Point(0, 275);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(238, 31);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 7;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::name_sorter.Properties.Resources.top;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(238, 31);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 2;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox2.Image = global::name_sorter.Properties.Resources.top;
            this.pictureBox2.Location = new System.Drawing.Point(477, 0);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(240, 31);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 3;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox3.Image = global::name_sorter.Properties.Resources.bottom;
            this.pictureBox3.Location = new System.Drawing.Point(477, 275);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(240, 31);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // tableLayoutPanel2
            // 
            this.tableLayoutPanel2.ColumnCount = 2;
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 79.0795F));
            this.tableLayoutPanel2.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20.9205F));
            this.tableLayoutPanel2.Controls.Add(this.TBP_CONTROL, 1, 0);
            this.tableLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel2.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel2.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel2.Name = "tableLayoutPanel2";
            this.tableLayoutPanel2.RowCount = 1;
            this.tableLayoutPanel2.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel2.Size = new System.Drawing.Size(717, 72);
            this.tableLayoutPanel2.TabIndex = 2;
            // 
            // LBL_UNSORTED
            // 
            this.LBL_UNSORTED.AutoSize = true;
            this.LBL_UNSORTED.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(240)))));
            this.LBL_UNSORTED.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LBL_UNSORTED.ForeColor = System.Drawing.Color.White;
            this.LBL_UNSORTED.Location = new System.Drawing.Point(12, 78);
            this.LBL_UNSORTED.Name = "LBL_UNSORTED";
            this.LBL_UNSORTED.Size = new System.Drawing.Size(143, 20);
            this.LBL_UNSORTED.TabIndex = 9;
            this.LBL_UNSORTED.Text = "Unsorted Names";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(240)))));
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(489, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(123, 20);
            this.label1.TabIndex = 10;
            this.label1.Text = "Sorted Names";
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.White;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(13, 350);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 11;
            this.button1.Text = "Open file";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.White;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(493, 350);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 12;
            this.button2.Text = "Open file";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // tableLayoutPanel3
            // 
            this.tableLayoutPanel3.ColumnCount = 1;
            this.tableLayoutPanel3.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel3.Controls.Add(this.panel1, 0, 1);
            this.tableLayoutPanel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel3.Location = new System.Drawing.Point(238, 31);
            this.tableLayoutPanel3.Margin = new System.Windows.Forms.Padding(0);
            this.tableLayoutPanel3.Name = "tableLayoutPanel3";
            this.tableLayoutPanel3.RowCount = 3;
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.tableLayoutPanel3.Size = new System.Drawing.Size(239, 244);
            this.tableLayoutPanel3.TabIndex = 13;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(240)))));
            this.panel1.Controls.Add(this.RB_GIVEN);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.RB_FIRST);
            this.panel1.Controls.Add(this.BTN_SORT);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 84);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(233, 75);
            this.panel1.TabIndex = 0;
            // 
            // BTN_SORT
            // 
            this.BTN_SORT.BackColor = System.Drawing.Color.White;
            this.BTN_SORT.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BTN_SORT.Location = new System.Drawing.Point(79, 43);
            this.BTN_SORT.Name = "BTN_SORT";
            this.BTN_SORT.Size = new System.Drawing.Size(75, 23);
            this.BTN_SORT.TabIndex = 12;
            this.BTN_SORT.Text = "Sort";
            this.BTN_SORT.UseVisualStyleBackColor = false;
            this.BTN_SORT.Click += new System.EventHandler(this.BTN_SORT_Click);
            // 
            // RB_FIRST
            // 
            this.RB_FIRST.AutoSize = true;
            this.RB_FIRST.Checked = true;
            this.RB_FIRST.Location = new System.Drawing.Point(75, 13);
            this.RB_FIRST.Name = "RB_FIRST";
            this.RB_FIRST.Size = new System.Drawing.Size(75, 17);
            this.RB_FIRST.TabIndex = 13;
            this.RB_FIRST.TabStop = true;
            this.RB_FIRST.Text = "First Name";
            this.RB_FIRST.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(176)))), ((int)(((byte)(240)))));
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(3, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(66, 16);
            this.label2.TabIndex = 14;
            this.label2.Text = "Sort By :";
            // 
            // RB_GIVEN
            // 
            this.RB_GIVEN.AutoSize = true;
            this.RB_GIVEN.Location = new System.Drawing.Point(151, 12);
            this.RB_GIVEN.Name = "RB_GIVEN";
            this.RB_GIVEN.Size = new System.Drawing.Size(84, 17);
            this.RB_GIVEN.TabIndex = 15;
            this.RB_GIVEN.Text = "Given Name";
            this.RB_GIVEN.UseVisualStyleBackColor = true;
            // 
            // name_sorter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(717, 378);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.LBL_UNSORTED);
            this.Controls.Add(this.TBP_BASE);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "name_sorter";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.name_sorter_Load);
            this.TBP_BASE.ResumeLayout(false);
            this.TBP_CONTROL.ResumeLayout(false);
            this.tableLayoutPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.DGV_UNSORTED)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.DGV_SORTED)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_HOW)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_CLOSE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.BTN_MIN)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.tableLayoutPanel2.ResumeLayout(false);
            this.tableLayoutPanel3.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel TBP_BASE;
        private System.Windows.Forms.TableLayoutPanel TBP_CONTROL;
        private System.Windows.Forms.PictureBox BTN_HOW;
        private System.Windows.Forms.PictureBox BTN_CLOSE;
        private System.Windows.Forms.PictureBox BTN_MIN;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView DGV_UNSORTED;
        private System.Windows.Forms.DataGridView DGV_SORTED;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel2;
        private System.Windows.Forms.Label LBL_UNSORTED;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel3;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.RadioButton RB_GIVEN;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RadioButton RB_FIRST;
        private System.Windows.Forms.Button BTN_SORT;
    }
}

